pkg = "Pingenator"
prog = "pingenator"
version = "0.3.0"
version_major = 0
version_minor = 3
version_micro = 0
version_devtag = ""
