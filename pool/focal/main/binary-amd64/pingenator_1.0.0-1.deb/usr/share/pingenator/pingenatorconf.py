pkg = "Pingenator"
prog = "pingenator"
version = "1.0.0"
version_major = 1
version_minor = 0
version_micro = 0
version_devtag = ""
